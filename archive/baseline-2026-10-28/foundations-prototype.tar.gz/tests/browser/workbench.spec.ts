import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
import type { CatalogEntry } from "../../src/catalog";
const catalog: CatalogEntry[] = JSON.parse(
  readFileSync(new URL("../../src/data/catalog.json", import.meta.url), "utf8"),
);
for (const entry of catalog) {
  test(`catalog: ${entry.id}`, async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(`/?item=${entry.id}&theme=light&lang=en`);
    await expect(
      page.getByRole("heading", { name: entry.name.en, exact: true }).first(),
    ).toBeVisible();
    if (entry.group !== "Review") {
      const demo = page.frameLocator("iframe").first();
      await expect(demo.locator("main")).toBeVisible();
      await expect(demo.locator("main")).not.toContainText("being connected");
      const meta = entry as typeof entry & { specimens?: { id: string }[] };
      for (const specimen of meta.specimens || []) {
        await expect(
          demo.locator(`[data-specimen="${specimen.id}"]`).first(),
          `${entry.id}/${specimen.id}`,
        ).toBeAttached();
      }
    }
    expect(errors).toEqual([]);
  });
}
test("presentation changes preserve input; reset clears it", async ({
  page,
}) => {
  await page.goto("/?item=fields&theme=light");
  const frame = page.frameLocator("iframe").first();
  const input = frame.getByRole("textbox").first();
  await input.fill("Retained sample");
  await page.getByLabel("Theme", { exact: true }).selectOption("dark");
  await page.getByLabel("Language", { exact: true }).selectOption("fr");
  await expect(input).toHaveValue("Retained sample");
  await page.getByLabel("Police", { exact: true }).selectOption("cairo");
  await page.getByLabel("Densité", { exact: true }).selectOption("compact");
  await page.getByLabel("Aperçu", { exact: true }).selectOption("360");
  await expect(input).toHaveValue("Retained sample");
  await page.getByLabel("Comparer", { exact: true }).selectOption("fonts");
  await expect(page.locator("iframe:visible")).toHaveCount(3);
  await page.getByLabel("Comparer", { exact: true }).selectOption("none");
  await expect(input).toHaveValue("Retained sample");
  await page
    .getByRole("button", { name: "Réinitialiser", exact: true })
    .click();
  await expect(input).not.toHaveValue("Retained sample");
  expect(page.url()).not.toContain("Retained");
});
test("overlay focus enters, stays, and returns", async ({ page }) => {
  await page.goto("/?item=overlays&theme=light");
  const frame = page.frameLocator("iframe").first();
  const trigger = frame.getByRole("button", {
    name: "Edit record",
    exact: true,
  });
  await trigger.click();
  const dialog = frame.getByRole("dialog", {
    name: "Edit sample record",
    exact: true,
  });
  await expect(dialog).toBeVisible();
  await expect(dialog.getByRole("textbox")).toBeFocused();
  for (let i = 0; i < 6; i++) await page.keyboard.press("Tab");
  expect(
    await dialog.evaluate((el) => el.contains(el.ownerDocument.activeElement)),
  ).toBeTruthy();
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(trigger).toBeFocused();
});
test("all fonts load locally; Arabic uses international digits", async ({
  page,
}) => {
  await page.goto("/?item=typography&lang=ar&theme=dark");
  const demo = page.frameLocator("iframe").first();
  await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  const text = await demo.locator("main").innerText();
  expect(text).not.toMatch(/[\u0660-\u0669\u06f0-\u06f9]/);
  for (const [font, family] of [
    ["ibm", "IBM Plex Sans Arabic"],
    ["noto", "Noto Sans Arabic"],
    ["cairo", "Cairo"],
  ]) {
    await page.getByLabel("الخط", { exact: true }).selectOption(font);
    const loaded = await page.locator("html").evaluate(async (_, family) => {
      await document.fonts.load(`400 16px "${family}"`);
      return document.fonts.check(`400 16px "${family}"`);
    }, family);
    expect(loaded).toBeTruthy();
  }
});
test("320px layout contains app controls; drawer works", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 900 });
  await page.goto("/?item=colors&lang=fr&theme=dark");
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(320);
  await page
    .getByRole("button", { name: "Ouvrir la navigation", exact: true })
    .click();
  await expect(
    page.getByRole("dialog", { name: "Navigation du catalogue" }),
  ).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(
    page.getByRole("button", { name: "Ouvrir la navigation", exact: true }),
  ).toBeFocused();
  await page
    .getByRole("button", { name: "Ouvrir la navigation", exact: true })
    .click();
  await page.getByRole("link", { name: "Typographie", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Typographie", exact: true }),
  ).toBeVisible();
});
test("state preview uses approved hover and pressed colors inside the isolated frame", async ({
  page,
}) => {
  await page.goto("/?item=buttons&state=hover&theme=light");
  const demo = page.frameLocator("iframe").first();
  const button = demo.getByRole("button", { name: "Add course", exact: true });
  await expect(button).toHaveCSS("background-color", "rgb(171, 20, 32)");
  await page.getByLabel("State", { exact: true }).selectOption("pressed");
  await expect(button).toHaveCSS("background-color", "rgb(142, 22, 33)");
  await page.goto('/?item=fields&state=hover&theme=light');
  await expect(page.frameLocator('iframe').first().getByRole('textbox',{name:'Full name',exact:true})).toHaveCSS('border-color','rgb(82, 82, 91)');
});
test("downloads match canonical values; real clipboard copy works", async ({
  page,
  context,
}) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  await page.goto("/?item=exports&theme=light");
  const downloadPromise = page.waitForEvent("download");
  await page
    .getByRole("link", { name: "Canonical color tokens", exact: false })
    .click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe("sis-ejust-palette.tokens.json");
  await page
    .getByRole("button", { name: "Copy token example", exact: true })
    .click();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toContain(
    "var(--sys-color-text-primary)",
  );
});
test("reduced motion and offline font weights preserve the foundation contract", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce", colorScheme: "dark" });
  await page.goto("/?item=motion&theme=system");
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  expect(
    await page
      .locator("html")
      .evaluate((el) =>
        getComputedStyle(el)
          .getPropertyValue("--sys-motion-duration-standard")
          .trim(),
      ),
  ).toBe("0ms");
  for (const family of ["IBM Plex Sans Arabic", "Noto Sans Arabic", "Cairo"])
    for (const weight of [400, 500, 600, 700])
      expect(
        await page.evaluate(
          async ({ family, weight }) => {
            await document.fonts.load(`${weight} 16px "${family}"`);
            return document.fonts.check(`${weight} 16px "${family}"`);
          },
          { family, weight },
        ),
      ).toBeTruthy();
});
test("theme comparison preserves the saved preference", async ({ page }) => {
  await page.goto("/?item=buttons&theme=light");
  await page.getByLabel("Compare", { exact: true }).selectOption("themes");
  await expect(page.locator("iframe:visible")).toHaveCount(2);
  expect(await page.evaluate(() => localStorage.getItem("sis.theme"))).toBe(
    "light",
  );
});

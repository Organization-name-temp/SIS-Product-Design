# SIS Foundations

The workbench contains 38 catalog pages and 148 named specimens. It uses local sample data.
Adham controls design approval. The interface does not edit foundation values.

## Preview

Run `npm ci --legacy-peer-deps`, then `npm run dev -- --host 0.0.0.0 --port 4173`.
The local preview opens at http://localhost:4173.
The preview starts with Colors and themes. The sidebar searches all three languages.

Presentation settings use URL parameters. Entered values stay in memory and do not enter URLs.
Only the main workbench saves its theme preference. Comparison frames do not save preferences.
Reset clears the selected demonstration. Reload clears all sample interactions.

## Sources

- `src/data/catalog.json` defines navigation, translations, specimens, states, token references, guidance, and verification cases.
- `../sis-ejust-palette.tokens.json` defines reference colors, semantic roles, and component aliases.
- `../sis-typography.tokens.json` defines font candidates, weights, roles, and number rules.
- `src/data/decisions.json` records the approved foundation decisions.
- `src/foundations.css` defines approved spacing, radii, targets, layout, and motion values.
- `public/reference/colors-workbench.png` defines the visual structure.
- `public/exports/sis-foundation-contract.md` contains the approved foundation contract.

`npm run tokens:generate` reads the canonical files above and generates application CSS, token exports, and the Figma mapping.
The files under `src/data/` are generated snapshots. A copied project can build from these snapshots when canonical files are absent.
Keep the three exported CSS files together. The foundation file imports color and typography styles.

The visual reference contains approximate generated colors. Canonical token values take priority.
The reference uses smaller swatch labels. This workbench keeps the approved 14px minimum and wraps the swatch grid.

## Catalog

Foundations cover colors, typography, spacing, grids, borders, icons, layers, motion, and accessibility.
Components cover 16 families. Patterns cover 10 local flows.
Coverage links open named examples. Conditional examples reveal the required step or dialog.
Usage snippets import renderers from this project. They are not an external component package.

Every scenario labels its sample data. Example rules do not establish university policy.
Upload controls keep selected files in this browser. No request sends them to a server.

## Verification

Run `npm run verify` for TypeScript, catalog coverage, token checks, build, and the Sites runtime tests.
Run `npm run test:browser -- --workers=1` for browser interaction tests.
Run `node scripts/audit-browser.mjs` for WCAG scans and narrow layout checks.
The QA report records visual findings, corrections, evidence, and test limits.

The starter retains its Sites build structure. The build does not publish the prototype.

## Fonts and licenses

The project serves IBM Plex Sans Arabic, Noto Sans Arabic, and Cairo from `public/fonts/`.
Each font includes its SIL Open Font License. The interface does not request remote fonts.
Google Fonts source links remain in the typography source file.

## Proposed details

The workbench uses a transition easing curve and layer numbers for local demonstrations.
These details remain proposals. They do not add approved foundation values.
Design changes come through chat and update the source files.
